<?php
session_start();
// define('root', $_SERVER['DOCUMENT_ROOT'] . '/curso_php/proyecto_dulceria/');


// if(isset($_SESSION['usuario_id'])){
//     require_once root.'views/capturar_productos_view.php';
// }else {
//     echo "no  estas logueado";
// }